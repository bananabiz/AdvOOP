﻿// Code provided by: Nick Gravelyn
// from: https://gist.github.com/nickgravelyn/7460288

using UnityEngine;

namespace Tiled2Unity
{
    // Component does nothing; editor script does all the magic
    public class SortingLayerExposed : MonoBehaviour
    {
    }
}