Textures directory

Tiled2Unity scripts will create textures here. In the case where Tiled tilesets 
already reference textures in your Unity project then the materials will use 
those textures instead of creating new textures here.